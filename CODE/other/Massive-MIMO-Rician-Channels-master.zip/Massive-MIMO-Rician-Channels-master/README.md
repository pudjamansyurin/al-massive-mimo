# Massive-MIMO-Rician-Channels

This code computes the spectral efficiency in the downlink of a Massive MIMO systems over Uncorrelated Rician Fading Channels. In particular, it generates Figs. 4 and 5 of a manuscript that is currently under review for publication on IEEE Transactions on Communications (submitted May 2018). The manuscript will be made available soon on arxiv.
